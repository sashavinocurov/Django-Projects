from django.apps import AppConfig


class FirstdjangoappConfig(AppConfig):
    name = 'firstdjangoapp'
