from django.apps import AppConfig


class TravelappConfig(AppConfig):
    name = 'travelapp'
