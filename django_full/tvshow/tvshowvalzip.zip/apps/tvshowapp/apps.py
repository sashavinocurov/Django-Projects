from django.apps import AppConfig


class TvshowappConfig(AppConfig):
    name = 'tvshowapp'
